delete from UnidadeMedida where un = 'UN';
select * from produto where un = 'UN';