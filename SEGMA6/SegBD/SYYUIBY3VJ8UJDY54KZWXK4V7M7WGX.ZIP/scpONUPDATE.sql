update UnidadeMedida set un = 'K' where un = 'KG';

select * from produto where un = 'KG';