Select 
         produto.dsprod,
         UnidadeMedida.dsmedida,
         produto.prvenda
from Produto 
left Join UnidadeMedida on Unidademedida.un = produto.un; 
